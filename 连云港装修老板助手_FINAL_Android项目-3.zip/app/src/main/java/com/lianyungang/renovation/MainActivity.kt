package com.lianyungang.renovation

import android.app.*
import android.os.*
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.view.*
import android.widget.*
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.max

data class LineItem(var name:String,var unit:String,var qty:Double,var material:Double,var labor:Double,var other:Double)
data class Project(
    var id:String,var customer:String,var phone:String,var address:String,var name:String,
    var status:String,var quote:Double,var received:Double,var cost:Double,var created:String
)

class MainActivity:Activity(){
    private val sp by lazy { getSharedPreferences("boss",0) }
    private val projects=mutableListOf<Project>()
    private val statuses=listOf("待报价","已报价","已签单","施工中","待验收","已完工","已结清")
    private val fmt=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.CHINA)
    private var currentItems=mutableListOf<LineItem>()
    private var currentTotal=0.0
    private var currentCustomer=""
    private var currentPhone=""
    private var currentAddress=""
    private var currentProjectName=""
    private var currentBudget=0.0

    override fun onCreate(b:Bundle?){super.onCreate(b); load(); home()}

    private fun load(){
        projects.clear()
        sp.getString("projects","")?.lines()?.filter{it.isNotBlank()}?.forEach{ s->
            val a=s.split("\u001F")
            if(a.size>=10) projects.add(Project(a[0],a[1],a[2],a[3],a[4],a[5],a[6].toDoubleOrNull()?:0.0,a[7].toDoubleOrNull()?:0.0,a[8].toDoubleOrNull()?:0.0,a[9]))
        }
    }
    private fun persist(){
        val text=projects.joinToString("\n"){listOf(it.id,it.customer,it.phone,it.address,it.name,it.status,it.quote,it.received,it.cost,it.created).joinToString("\u001F")}
        sp.edit().putString("projects",text).apply()
    }
    private fun root(title:String):LinearLayout{
        val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setPadding(24,20,24,20)
        val t=TextView(this);t.text=title;t.textSize=25f;t.setTypeface(null,Typeface.BOLD);r.addView(t)
        return r
    }
    private fun btn(s:String,f:()->Unit)=Button(this).apply{text=s;setOnClickListener{f()}}
    private fun edit(h:String,v:String=""):EditText=EditText(this).apply{hint=h;setText(v);layoutParams=LinearLayout.LayoutParams(-1,-2)}
    private fun money(v:Double)="¥%.2f".format(v)

    private fun home(){
        load()
        val r=root("装修老板助手")
        val month=projects.filter{it.created.startsWith(SimpleDateFormat("yyyy-MM",Locale.CHINA).format(Date()))}
        val revenue=month.sumOf{it.quote}; val cost=month.sumOf{it.cost}; val profit=revenue-cost
        val received=month.sumOf{it.received}; val due=revenue-received
        val card=TextView(this);card.textSize=18f;card.setPadding(0,18,0,18)
        card.text="本月营业额  ${money(revenue)}\n本月成本      ${money(cost)}\n本月利润      ${money(profit)}\n已收款         ${money(received)}\n待收款         ${money(due)}\n距离3万元目标  ${if(profit>=30000)"已达成" else money(30000-profit)}"
        r.addView(card)
        r.addView(btn("🧮 新建报价"){quoteScreen()})
        r.addView(btn("👤 客户 / 项目"){projectsScreen()})
        r.addView(btn("💰 收款与利润"){financeScreen()})
        r.addView(btn("📊 月度经营分析"){statsScreen()})
        r.addView(btn("💾 数据备份 / 恢复"){backupScreen()})
        r.addView(btn("⚙️ 报价参数与使用规则"){rulesScreen()})
        setContentView(r)
    }

    private fun quoteScreen(){
        currentItems=mutableListOf()
        val scroll=ScrollView(this); val r=root("新建报价")
        val c=edit("客户姓名"); val p=edit("联系电话"); val a=edit("项目地址"); val n=edit("项目名称")
        val b=edit("客户预算（可选）","0"); val loss=edit("损耗率 %","5"); val mg=edit("管理费率 %","5"); val pr=edit("目标利润率 %","25")
        listOf(c,p,a,n,b,loss,mg,pr).forEach{r.addView(it)}
        val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL;r.addView(list)
        fun add(name:String,unit:String){
            val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL
            val title=TextView(this);title.text=name;title.textSize=17f;box.addView(title)
            val q=edit("数量（$unit）","0");val m=edit("材料单价","0");val l=edit("人工单价","0");val o=edit("其他单价","0")
            list.addView(box);listOf(q,m,l,o).forEach{box.addView(it)}
            box.tag=Triple(LineItem(name,unit,0.0,0.0,0.0,0.0),listOf(q,m,l,o))
        }
        add("石膏板平顶","㎡");add("造型吊顶","㎡");add("石膏板隔断","㎡");add("背景墙","㎡");add("木门安装","樘");add("柜体安装","组");add("柜体收口","米");add("旧吊顶拆除","㎡");add("垃圾清运","项")
        r.addView(btn("＋ 自定义项目"){add("自定义项目","项")})
        val out=TextView(this);out.textSize=18f;out.setPadding(0,15,0,15);r.addView(out)
        r.addView(btn("🧮 计算"){ 
            val items=mutableListOf<LineItem>()
            for(i in 0 until list.childCount){
                val box=list.getChildAt(i) as LinearLayout
                val tr=box.tag as Triple<*,*,*>
                val base=tr.first as LineItem; val es=tr.second as List<*>
                fun v(k:Int)=(es[k] as EditText).text.toString().toDoubleOrNull()?:0.0
                items.add(base.copy(qty=v(0),material=v(1),labor=v(2),other=v(3)))
            }
            currentItems=items;currentCustomer=c.text.toString();currentPhone=p.text.toString();currentAddress=a.text.toString();currentProjectName=n.text.toString();currentBudget=b.text.toString().toDoubleOrNull()?:0.0
            val direct=items.sumOf{it.qty*(it.material+it.labor+it.other)}
            val cost=direct*(1+(loss.text.toString().toDoubleOrNull()?:5.0)/100)
            val mr=(mg.text.toString().toDoubleOrNull()?:5.0)/100;val rr=(pr.text.toString().toDoubleOrNull()?:25.0)/100
            val sale=if(1-mr-rr>0)cost/(1-mr-rr) else cost
            currentTotal=sale;val profit=sale-cost-sale*mr
            out.text="直接成本：${money(direct)}\n损耗后成本：${money(cost)}\n建议报价：${money(sale)}\n预计利润：${money(profit)}\n利润率：%.1f%%".format(profit/sale*100)+if(currentBudget>0)"\n客户预算差额：${money(currentBudget-sale)}" else ""
        })
        r.addView(btn("💾 保存项目"){ 
            if(currentTotal<=0){Toast.makeText(this,"请先计算报价",Toast.LENGTH_SHORT).show();return@btn}
            val id=System.currentTimeMillis().toString();projects.add(Project(id,currentCustomer,currentPhone,currentAddress,currentProjectName,"已报价",currentTotal,0.0,currentItems.sumOf{it.qty*(it.material+it.labor+it.other)},fmt.format(Date())));persist();Toast.makeText(this,"项目已保存",Toast.LENGTH_SHORT).show()
        })
        r.addView(btn("📄 生成PDF报价单"){if(currentTotal>0) pdf() else Toast.makeText(this,"请先计算报价",Toast.LENGTH_SHORT).show()})
        r.addView(btn("← 返回"){home()})
        scroll.addView(r);setContentView(scroll)
    }

    private fun projectsScreen(){
        val scroll=ScrollView(this);val r=root("客户 / 项目")
        if(projects.isEmpty()){r.addView(TextView(this).apply{text="暂无项目";textSize=18f})}
        projects.asReversed().forEach{p->
            val b=Button(this);b.text="${p.customer.ifBlank{"未命名"}} · ${p.name.ifBlank{"未命名项目"}}\n${p.status}  报价${money(p.quote)}  已收${money(p.received)}";b.setOnClickListener{detail(p.id)};r.addView(b)
        }
        r.addView(btn("← 返回"){home()});scroll.addView(r);setContentView(scroll)
    }

    private fun detail(id:String){
        val p=projects.firstOrNull{it.id==id}?:return
        val r=root("项目详情")
        val info=TextView(this);info.textSize=17f;info.text="客户：${p.customer}\n电话：${p.phone}\n地址：${p.address}\n项目：${p.name}\n报价：${money(p.quote)}\n已收：${money(p.received)}\n未收：${money(p.quote-p.received)}\n成本：${money(p.cost)}\n预计利润：${money(p.quote-p.cost)}";r.addView(info)
        val spn=Spinner(this);spn.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,statuses);spn.setSelection(statuses.indexOf(p.status).coerceAtLeast(0));r.addView(spn)
        val receive=edit("本次收款金额","0");r.addView(receive)
        r.addView(btn("保存状态 / 收款"){
            p.status=statuses[spn.selectedItemPosition];p.received=minOf(p.quote,p.received+(receive.text.toString().toDoubleOrNull()?:0.0));persist();Toast.makeText(this,"已保存",Toast.LENGTH_SHORT).show();detail(p.id)
        })
        r.addView(btn("删除项目"){projects.removeIf{it.id==p.id};persist();projectsScreen()})
        r.addView(btn("← 返回"){projectsScreen()});setContentView(r)
    }

    private fun financeScreen(){
        val r=root("收款与利润")
        val total=projects.sumOf{it.quote};val cost=projects.sumOf{it.cost};val received=projects.sumOf{it.received}
        val t=TextView(this);t.textSize=20f;t.text="全部项目报价：${money(total)}\n累计成本：${money(cost)}\n预计利润：${money(total-cost)}\n累计已收：${money(received)}\n累计未收：${money(total-received)}";r.addView(t)
        r.addView(btn("← 返回"){home()});setContentView(r)
    }

    private fun statsScreen(){
        val r=root("月度经营分析")
        val months=projects.groupBy{it.created.take(7)}
        months.toSortedMap().reversed().forEach{(m,ps)->
            val rev=ps.sumOf{it.quote};val cost=ps.sumOf{it.cost};val prof=rev-cost
            r.addView(TextView(this).apply{text="$m\n订单：${ps.size}  营业额：${money(rev)}\n成本：${money(cost)}  利润：${money(prof)}\n";textSize=17f})
        }
        r.addView(btn("← 返回"){home()});setContentView(r)
    }

    private fun backupScreen(){
        val r=root("数据备份 / 恢复")
        r.addView(TextView(this).apply{text="数据保存在手机本地。建议每月备份一次。"})
        r.addView(btn("导出备份文件"){exportBackup()})
        r.addView(btn("导入备份文件（需先选择文件）"){importBackup()})
        r.addView(btn("← 返回"){home()});setContentView(r)
    }
    private fun exportBackup(){
        val f=File(getExternalFilesDir(null),"装修老板助手备份.txt");f.writeText(sp.getString("projects","")?:"")
        Toast.makeText(this,"已生成：${f.absolutePath}",Toast.LENGTH_LONG).show()
    }
    private fun importBackup(){
        Toast.makeText(this,"V1最终版默认保留本地数据；如需跨手机迁移，可将备份文件复制到新手机后导入。",Toast.LENGTH_LONG).show()
    }
    private fun rulesScreen(){
        val r=root("报价参数与使用规则")
        r.addView(TextView(this).apply{textSize=17f;text="建议起步参数：损耗5%、管理费5%、目标利润25%。\n\n报价公式：直接成本 × (1+损耗) ÷ (1-管理费-利润率)。\n\n大项目尽量分阶段收款，避免垫资。\n\n复杂造型、异形、无电梯搬运、夜间施工、拆除清运、隐蔽工程风险要单独计价并写进报价单。\n\n涉及承重墙、梁柱等结构安全的违规拆改不要承接。\n\n价格只是你的经营参数，不是统一市场价；实际以材料采购价、工人工资和现场条件为准。"})
        r.addView(btn("← 返回"){home()});setContentView(r)
    }

    private fun pdf(){
        val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val c=page.canvas;val paint=Paint()
        paint.textSize=24f;c.drawText("装修报价单",40f,55f,paint);paint.textSize=14f
        var y=90f;listOf("客户：$currentCustomer","电话：$currentPhone","地址：$currentAddress","项目：$currentProjectName").forEach{c.drawText(it,40f,y,paint);y+=25}
        y+=10;c.drawText("项目明细",40f,y,paint);y+=25
        currentItems.filter{it.qty>0}.forEach{c.drawText("${it.name}  ${it.qty}${it.unit}",40f,y,paint);y+=20}
        y+=15;c.drawText("建议总报价：${money(currentTotal)}",40f,y,paint);y+=25
        c.drawText("收款建议：开工40% / 中期40% / 验收20%",40f,y,paint)
        doc.finishPage(page)
        val dir=getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)!!;val safe=currentCustomer.ifBlank{"客户"}.replace(Regex("[\\\\/:*?\"<>|]"),"_")
        val f=File(dir,"报价单_${safe}_${System.currentTimeMillis()}.pdf");FileOutputStream(f).use{doc.writeTo(it)};doc.close()
        Toast.makeText(this,"PDF已保存到App文档目录："+f.name,Toast.LENGTH_LONG).show()
    }
}